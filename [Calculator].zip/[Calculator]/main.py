
firstNum = int(input('First Number: '))
secondNum = int(input('Second Number     '))
print('What action do u need? : +, -, *, /')
action = str(input())
d = 0

if action == '+':
    d = firstNum + secondNum
elif action == '*':
    d = firstNum * secondNum
elif action == '-':
    d = firstNum - secondNum
elif action == '/':
    d = firstNum / secondNum
else:
    print('Error')

print("Result:", d)
